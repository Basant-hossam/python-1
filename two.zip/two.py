import turtle
mary = turtle.Turtle()
mary.color("purple")
mary.width(5)
for side in [1, 2, 3, 4, 5]:
    mary.forward(100)
    mary.right(72)


import turtle
juno = turtle.Turtle()
juno.color("yellow")
juno.width(5)
juno.forward(100)
juno.left(120)
juno.forward(100)
juno.left(120)
juno.forward(100)
juno.left(120)

import turtle
amy = turtle.Turtle()
amy.color("cyan")
amy.width(5)
for item in [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]:
    amy.forward(50)
    amy.right(30)
    